#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <unistd.h>
#include <mosquitto.h>

#define MQTT_HOSTNAME "localhost"
#define MQTT_PORT 1883
#define MQTT_USERNAME "admin"
#define MQTT_PASSWORD "admin"
#define MQTT_TOPIC "myTopic"

int init_mosq(){
    struct mosquitto *mosq = NULL;
    mosquitto_lib_init();
    mosq = mosquitto_new(NULL, true, NULL);

    if(!mosq){
        printf("Cant initialize mosquitto library\n");
	    printf("1\n");
        exit(-1);
    }

    mosquitto_username_pw_set(mosq, MQTT_USERNAME, MQTT_PASSWORD);

    int ret = mosquitto_connect(mosq, MQTT_HOSTNAME, MQTT_PORT, 0);

    if(ret){
        printf("Cant connect to mosquitto server\n");
	printf("2\n");
        exit(-1);
    }
}

int mosq_pub(char *text){
    text = "Nice to meet u\n";

    ret = mosquitto_publish(mosq, NULL, MQTT_TOPIC, strlen(text), text, 0, false);

    if(ret){
        printf("Cant connect to mosquitto server\n");
	printf("3\n");
        exit(-1);
    }

    sleep(1);

    mosquitto_disconnect(mosq);
    mosquitto_destroy(mosq);
    mosquitto_lib_cleanup();

    return 0;
}
